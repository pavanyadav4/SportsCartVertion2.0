package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.CardDetail;

public interface CardDetailDAO {

	boolean saveOrUpdate(CardDetail cardDetail);
	
}
