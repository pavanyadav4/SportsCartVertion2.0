package com.sports.dao;

import java.util.List;

import com.sports.model.OrderedItems;

public interface OrderedItemsDAO {

	void saveOrUpdate(OrderedItems orderedItems );
	
	void delete(String orderedItemId);
	
	List<OrderedItems> listOrderedItems();
}
