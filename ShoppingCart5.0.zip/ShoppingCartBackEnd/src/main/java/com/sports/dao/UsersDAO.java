package com.sports.dao;

import com.sports.model.Users;

public interface UsersDAO {

	void saveOrUpdate(Users users);
	
	void delete(String customerId);
}
