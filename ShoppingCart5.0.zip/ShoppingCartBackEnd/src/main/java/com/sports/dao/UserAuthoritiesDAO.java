package com.sports.dao;

import com.sports.model.UserAuthorities;

public interface UserAuthoritiesDAO {
	void saveOrUpdate(UserAuthorities userAuthorities);

	void delete(String customerId);
}
