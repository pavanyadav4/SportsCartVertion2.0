package com.sports.dao;

import com.sports.model.CardDetail;

public interface CardDetailDAO {

	void saveOrUpdate(CardDetail cardDetail);
	
}
