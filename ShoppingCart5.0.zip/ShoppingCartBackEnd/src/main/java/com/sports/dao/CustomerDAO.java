package com.sports.dao;

import java.util.List;

import com.sports.model.Customer;

public interface CustomerDAO {

	void saveOrUpdate(Customer customer);
	
	Customer get(String customerId);
	
	List<Customer> listCustomer();
	
	Customer getCustomerByUserName(String userName);
}
