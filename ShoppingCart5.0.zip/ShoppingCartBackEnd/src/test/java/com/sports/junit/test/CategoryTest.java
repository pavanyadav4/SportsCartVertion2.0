package com.sports.junit.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sports.dao.CategoryDAO;
import com.sports.model.Category;

public class CategoryTest {

	static Category category;

	static CategoryDAO categoryDAO;

	static AnnotationConfigApplicationContext context;

	@BeforeClass
	public static void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.ahmad");
		context.refresh();
		category = (Category) context.getBean("category");
		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
	}

	/*@Test
	public void listCategory() {
		int cat = categoryDAO.listCategory().size();
		assertEquals("Test for list size category", 4, cat);
	}*/

	@Test
	public void addCategory(){
		category.setCategoryId("CG231");
		category.setCategoryName("CGNa32");
		category.setCategoryDescription("This isdesc");
	
		categoryDAO.saveOrUpdate(category);
		/*if(categoryDAO.saveOrUpdate(category)==true)
		{
			System.out.println("Category created successfully");
		}
		else{
			System.out.println("Not able to create the category");
		}*/
	}
	
/*	@Test
	public  void getCategoryName() {
		category = categoryDAO.get("CAT002");
		String name=category.getCategoryName();
		 assertEquals("This is a test for getting Name","Curtains",name);
	}*/
	
	
}
