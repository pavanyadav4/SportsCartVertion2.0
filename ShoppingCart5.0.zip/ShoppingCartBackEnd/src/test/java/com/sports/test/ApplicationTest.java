package com.sports.test;

public class ApplicationTest {

	public static void main(String[] args) {
		
		int [] a = null;
		
		for(int item: a) {
			
			System.out.println(item);
		}
		
		//if there are no cart items
		// if cartitemlist is null
		// else match with every cartitem with the product
		
		System.out.println("After for each!!");
		
	}

}
