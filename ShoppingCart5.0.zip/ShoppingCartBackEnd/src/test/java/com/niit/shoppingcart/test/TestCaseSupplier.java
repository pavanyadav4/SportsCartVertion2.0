package com.niit.shoppingcart.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class TestCaseSupplier {

	@Autowired
	SupplierDAO supplierDAO;
	@Autowired
	Supplier supplier;

	AnnotationConfigApplicationContext context;

	@Before
	public void init() {
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		supplier = (Supplier) context.getBean("supplier");
	}

	@Test
	public void supplierAddTestCase() {
		supplier.setid("hhasd");
		supplier.setname("sun");
		supplier.setaddress("this macro");
		assertEquals(supplierDAO.save(supplier), true);
	}

	/*
	 * @Test public void supplierListTestCase() { List<Supplier> list =
	 * supplierDAO.list(); int rowCount = list.size();
	 * assertEquals("Supplier List Test Case", rowCount,2); }
	 */

	/*
	 * @Test public void deleteTestCase(){ supplier.setid("MOB_002");
	 * assertEquals(supplierDAO.delete(supplier),true); }
	 */

	/*
	 * @Test public void updateTestCase(){ supplier.setid("SUP_001");
	 * supplier.setname("Micro"); supplier.setaddress("this is micro");
	 * assertEquals(supplierDAO.update(supplier),true); }
	 */

	/*
	 * @Test public void getSupplierTestCase(){ supplier=supplierDAO.get("001");
	 * System.out.println(supplier.getSup_address());
	 * assertEquals(supplier.getName(), "Micro technologies"); }
	 */

}
