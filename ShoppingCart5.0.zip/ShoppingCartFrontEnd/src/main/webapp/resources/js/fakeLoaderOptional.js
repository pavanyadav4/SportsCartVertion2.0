
/*$("#fakeLoader").fakeLoader({

	timeToHide : 1200, // Time in milliseconds for fakeLoader disappear

	zIndex : "999",// Default zIndex

	spinner : "spinner4",// Options: 'spinner1', 'spinner2', 'spinner3',
							// 'spinner4', 'spinner5', 'spinner6',
							// ---'spinner7----'

	bgColor : "#2ecc71", // Hex, RGB or RGBA colors

// imagePath:"yourPath/customizedImage.gif" //If you want can you insert your
// custom image

});
*/
(function() {
	$("#fakeLoader").fakeLoader({
		timeToHide : 1200,
		zIndex : 9999,
		spinner : "spinner6",
		bgColor : "#a01414"
	});
})();