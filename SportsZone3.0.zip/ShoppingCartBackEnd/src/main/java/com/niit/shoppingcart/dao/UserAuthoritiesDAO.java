package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.UserAuthorities;

public interface UserAuthoritiesDAO {
	void saveOrUpdate(UserAuthorities userAuthorities);

	void delete(String customerId);
}
