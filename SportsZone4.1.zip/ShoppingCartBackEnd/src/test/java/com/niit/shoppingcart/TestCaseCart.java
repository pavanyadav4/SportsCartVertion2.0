/*package com.niit.shoppingcart;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.model.Cart;

public class TestCaseCart {

AnnotationConfigApplicationContext context;
	
@Autowired
CartDAO cartDAO;

@Autowired
Cart cart;

	@Before
	public void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		cartDAO= (CartDAO)context.getBean("cartDAO");
		cart = (Cart)context.getBean("cart");
	}
	
	@Test
	public void categoryAddTestCase()
	{
		cart.setId("CART_01");
		cart.setPrice("500");
		cart.setProductName("Badminton");
		cart.setQuantity("2");
		cart.setStatus("Delivered");
		cart.setUserID("Nani");
		
		
		boolean flag = cartDAO.save(cart);
		assertEquals(flag, true);
	}
	

}
*/